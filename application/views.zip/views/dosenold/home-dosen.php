<div class="income-order-visit-user-area">
	<div class="container-fluid">
		<div class="row">

			<div class="col-lg-3">
				<div class="income-dashone-total shadow-reset nt-mg-b-30">
					<div class="income-title">
						<div class="main-income-head">
							<h2>Mahasiswa</h2>
							<div class="main-income-phara">

							</div>
						</div>
					</div>
					<div class="income-dashone-pro">
						<div class="income-rate-total">
							<div class="price-adminpro-rate">
								<h2><span class="counter">
										<?php echo $this->db->get('mahasiswa')->num_rows(); ?>
									</span></h2>
							</div>
							<div class="price-graph">
								<span><i class="fa fa-users fa-4x"></i></span>
							</div>
							<div class="income-range order-cl">
								<p>Total Mahasiswa</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="income-dashone-total shadow-reset nt-mg-b-30">
					<div class="income-title">
						<div class="main-income-head">
							<h2>Dosen</h2>
							<div class="main-income-phara">

							</div>
						</div>
					</div>
					<div class="income-dashone-pro">
						<div class="income-rate-total">
							<div class="price-adminpro-rate">
								<h2><span class="counter">
										<?php echo $this->db->get('dosen')->num_rows(); ?>
									</span></h2>
							</div>
							<div class="price-graph">
								<span><i class="fa fa-users fa-4x"></i></span>
							</div>
							<div class="income-range order-cl">
								<p>Total Dosen</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="income-dashone-total shadow-reset nt-mg-b-30">
					<div class="income-title">
						<div class="main-income-head">
							<h2>Matakuliah</h2>
							<div class="main-income-phara">

							</div>
						</div>
					</div>
					<div class="income-dashone-pro">
						<div class="income-rate-total">
							<div class="price-adminpro-rate">
								<h2><span class="counter">
										<?php echo $this->db->get('matakuliah')->num_rows(); ?>
									</span></h2>
							</div>
							<div class="price-graph">
								<span><i class="fa fa-file fa-4x"></i></span>
							</div>
							<div class="income-range order-cl">
								<p>Total Matakuliah</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="income-dashone-total shadow-reset nt-mg-b-30">
					<div class="income-title">
						<div class="main-income-head">
							<h2>Jurusan</h2>
							<div class="main-income-phara">

							</div>
						</div>
					</div>
					<div class="income-dashone-pro">
						<div class="income-rate-total">
							<div class="price-adminpro-rate">
								<h2><span class="counter">
										<?php echo $this->db->get('jurusan')->num_rows(); ?>
									</span></h2>
							</div>
							<div class="price-graph">
								<span><i class="fa fa-university fa-4x"></i></span>
							</div>
							<div class="income-range order-cl">
								<p>Total Jurusan</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>

		</div>

	</div>
</div>



<br><br><br><br><br><br><br><br><br>
<br><br><br><br><br>
