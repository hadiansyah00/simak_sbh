<div class="container-fluid">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="user-profile-wrap shadow-reset">
            <div class="row">
                <div class="col-md-7">
                    <div class="content-video">
                        <!-- Tempatkan Video Disini -->
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/fTC-PNFxkNk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div><p></p>
                    <footer>
                        <h3 class="text-center">Lihat Video</h3>
                    </footer>
                </div>
                <div class="col-md-5">
                    <h2>Alur Program</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>

<div class="pdf-viewer-area mg-b-40">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2">
            </div>
            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                <div class="pdf-single-pro shadow-reset">
                    <a class="media" href="<?php echo base_url()?>assets/pdf/blueprint.pdf"></a>
                </div>
            </div>
            <div class="col-lg-2">
            </div>
        </div>
    </div>
</div>
