  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
  	<div class="container">
  		<div class="copyright">
  			Copyright &copy; 2022 <strong><span><a href="https://sbh.ac.id/" target="_blank">STIKES BOGOR HUSADA</a></span></strong>
  		</div>
  		<div class="credits">
  			<!-- All the links in the footer should remain intact. -->
  			<!-- You can delete the links only if you purchased the pro version. -->
  			<!-- Licensing information: https://bootstrapmade.com/license/ -->
  			<!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/ -->
  			Created by <a href="" target="_blank">IT DIVISION</a> <?php echo date('Y'); ?>
  		</div>
  	</div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/typed.js/typed.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>assets/assets-mhs/js/main.js"></script>


  </body>

  </html>
