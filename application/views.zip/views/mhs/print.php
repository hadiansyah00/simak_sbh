<section>
	<div class="container">
		<table>
			<tr>
				<th style="width: 50px;"></th>
				<th> </th>
				<th>
					<p>
					<h3>Cek Administrasi / Verfikasi Pembayaran ke <font color="red"> BAUK!</font>

					</h3>
					<hr>
					<h4>KRS <strong><?php echo $mhs['nama_mhs']; ?></strong> Belum bisa diakses Agar bisa diakses Silahkan Hubungi pihak <b>
							<font color="red"> BAUK!</font>
							</font>
							</p>
				</th>
			</tr>
		</table>
	</div>
</section>
