  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
   <div class="footer-copyright-area">
   	<div class="container-fluid">
   		<div class="row">
   			<div class="col-lg-8 text-right">
   				<div class="footer-copy-center">
   					<p>Copyright &#169; 2022 <a href="https://sbh.ac.id/" target="_blank">STIKES BOGOR HUSADA</a> | <a href="" target="_blank">IT DIVISON</a> <?php echo date('Y'); ?>.</p>
   				</div>
   			</div>
   		</div>
   	</div>
   </div>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/typed.js/typed.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>assets/assets-mhs/js/main.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-1.11.3.min.js"></script>
   <!-- bootstrap JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
   <!-- meanmenu JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/jquery.meanmenu.js"></script>
   <!-- mCustomScrollbar JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
   <!-- sticky JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/jquery.sticky.js"></script>
   <!-- scrollUp JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/jquery.scrollUp.min.js"></script>
   <!-- counterup JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/counterup/jquery.counterup.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/counterup/waypoints.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/counterup/counterup-active.js"></script>
   <!-- peity JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/peity/jquery.peity.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/peity/peity-active.js"></script>
   <!-- sparkline JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/sparkline/jquery.sparkline.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/sparkline/sparkline-active.js"></script>
   <!-- flot JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.tooltip.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.spline.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.resize.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.pie.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/flot/Chart.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/flot/flot-active.js"></script>
   <!-- pdf JS
        ============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/pdf/jquery.media.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/pdf/pdf-active.js"></script>
   <!-- map JS
		============================================ -->

   <script src="<?php echo base_url(); ?>assets/assets-mhs/vendor/jquery.min.map"></script>
   <script src="<?php echo base_url(); ?>assets/js/map/raphael.min.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/map/jquery.mapael.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/map/france_departments.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/map/world_countries.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/map/usa_states.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/map/map-active.js"></script>
   <!-- data table JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/data-table/bootstrap-table.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/tableExport.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/data-table-active.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/bootstrap-table-editable.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/bootstrap-editable.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/bootstrap-table-resizable.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/colResizable-1.5.source.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/data-table/bootstrap-table-export.js"></script>
   <!-- modal JS
        ============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/modal-active.js"></script>
   <!-- main JS
		============================================ -->
   <script src="<?php echo base_url(); ?>assets/js/main.js"></script>

  </body>

  </html>
